-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 20 2018 г., 07:59
-- Версия сервера: 5.6.41
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `baza3`
--

-- --------------------------------------------------------

--
-- Структура таблицы `batches`
--

CREATE TABLE `batches` (
  `id` int(11) NOT NULL,
  `batchpm` varchar(55) NOT NULL,
  `m_operation_id` varchar(55) NOT NULL,
  `vremya` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `summa` float NOT NULL,
  `segodnya` varchar(12) NOT NULL,
  `frod` int(1) NOT NULL DEFAULT '0',
  `summa_rub` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `deposits`
--

CREATE TABLE `deposits` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `curatorid` int(11) NOT NULL,
  `summa` double(10,2) NOT NULL,
  `unixtime` bigint(20) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `summa` float NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `comment` text CHARACTER SET utf8 NOT NULL,
  `type` int(11) NOT NULL COMMENT '0 - нейтрально (отладка), 1 - положительное действие (green), 2 - отрицательное (red)',
  `status` int(1) NOT NULL DEFAULT '0',
  `timeunix` int(22) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `more`
--

CREATE TABLE `more` (
  `id` int(11) NOT NULL,
  `plus` double(10,2) NOT NULL,
  `minus` double(10,2) NOT NULL,
  `feikuser` int(4) NOT NULL,
  `start` text NOT NULL,
  `vk` text NOT NULL,
  `telega` text NOT NULL,
  `mail` text CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `more`
--

INSERT INTO `more` (`id`, `plus`, `minus`, `feikuser`, `start`, `vk`, `telega`, `mail`) VALUES
(1, 0.00, 0.00, 0, '26.10.2018', 'https://vk.com/', 'https://t.me/', 'admin@project.com');

-- --------------------------------------------------------

--
-- Структура таблицы `ss_users`
--

CREATE TABLE `ss_users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `wallet` varchar(15) NOT NULL,
  `wallet_password` varchar(64) NOT NULL,
  `curator` int(11) NOT NULL,
  `i_have_refs_as_curator` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL COMMENT 'IP пользователя при регистрации',
  `last_ip` varchar(15) NOT NULL COMMENT 'IP пользователя при последнем входе в аккаунт',
  `came` varchar(50) NOT NULL COMMENT 'Откуда пришел',
  `act_1` int(1) NOT NULL DEFAULT '0',
  `reg_unix` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Таблица юзеров';

--
-- Дамп данных таблицы `ss_users`
--

INSERT INTO `ss_users` (`id`, `email`, `wallet`, `wallet_password`, `curator`, `i_have_refs_as_curator`, `ip`, `last_ip`, `came`, `act_1`, `reg_unix`) VALUES
(1, 'admin@local', 'P48420484', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 9, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(2, 'feik1@local', 'P56816***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540388501),
(3, 'feik2@local', 'P72359***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540547006),
(4, 'feik3@local', 'P35674***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540547016),
(5, 'feik4@local', 'P22598***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540547026),
(6, 'feik5@local', 'P44625***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540801736),
(7, 'feik6@local', 'P26084***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540801739),
(8, 'feik7@local', 'P40711***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540801949),
(9, 'feik8@local', 'P84665***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540801952),
(10, 'feik9@local', 'P66346***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802025),
(11, 'feik10@local', 'P75510***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802027),
(12, 'feik11@local', 'P38416***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802142),
(13, 'feik12@local', 'P44847***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802145),
(14, 'feik13@local', 'P85388***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802338),
(15, 'feik14@local', 'P67407***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802342),
(16, 'feik15@local', 'P45336***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802343),
(17, 'feik16@local', 'P75863***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802344),
(18, 'feik17@local', 'P72174***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802345),
(19, 'feik18@local', 'P87411***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802474),
(20, 'feik19@local', 'P44982***', '', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540802476);

-- --------------------------------------------------------

--
-- Структура таблицы `userstat`
--

CREATE TABLE `userstat` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `type` varchar(100) CHARACTER SET utf8 NOT NULL,
  `opisanie` text CHARACTER SET utf8 NOT NULL,
  `color` varchar(50) CHARACTER SET utf8 NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `summa` float DEFAULT NULL,
  `comment` varchar(33) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `userstat`
--

INSERT INTO `userstat` (`id`, `userid`, `type`, `opisanie`, `color`, `data`, `summa`, `comment`) VALUES
(1, 1, 'Вход', '::1', 'black', '2018-12-16 14:58:39', 0, ''),
(2, 23, 'Регистрация', '::1', 'black', '2018-12-16 15:03:08', 0, ''),
(3, 23, 'Вход', '::1', 'black', '2018-12-16 15:28:40', 0, ''),
(4, 1, 'Вход', '::1', 'black', '2018-12-18 10:34:37', 0, ''),
(10, 1, 'Вход', '', 'black', '2018-12-18 15:32:37', 0, '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `batches`
--
ALTER TABLE `batches`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `more`
--
ALTER TABLE `more`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `ss_users`
--
ALTER TABLE `ss_users`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `ss_users` ADD FULLTEXT KEY `came` (`came`);

--
-- Индексы таблицы `userstat`
--
ALTER TABLE `userstat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `batches`
--
ALTER TABLE `batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `more`
--
ALTER TABLE `more`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `ss_users`
--
ALTER TABLE `ss_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT для таблицы `userstat`
--
ALTER TABLE `userstat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
