<?if(empty($id)){?>

<div class="lider" style="height: 130px;box-shadow: 0px 0px 25px 5px rgba(0, 0, 0, 0.09);position: relative;">
<header class="theme-menu-two transparent-menu">
<div class="main-header">
<div class="container">
<div class="logo float-left" style="margin-left: 20px;">
<a href="/"><img src="/tema/img/logo.png" style="position: absolute;width: 250px;margin-left: -10px;margin-top: 0px;"></a>
</div>

<div class="menu-wrapper float-right">
<nav id="mega-menu-holder" class="menuzord menuzord-responsive">
<ul class="menuzord-menu menuzord-indented scrollable">
<li><a href="/">Главная</a></li>
<li><a href="/about"> О проекте</a></li>
<li><a href="/rules"> Правила</a></li>
<li><a href="/faq"> FAQ</a></li>
<li><a href="/contacts"> Контакты</a></li>
<li><a href="<?=$vkgrup?>" target="_blank"><i class="fa fa-vk"></i></a></li>
<li><a href="<?=$telega?>" target="_blank"><i class="fa fa-send"></i></a></li>
</ul>
</nav> 
</div> 
</div> 
</div>
</header>
</div>
<style>
.about__description {
font-size: 15px;
color: #252e43;
line-height: 30px;
font-weight: 400;
margin-top: 15px;
font-family: 'Montserrat', sans-serif;
text-align: left;
width: 100%;
margin: 0 auto;
margin-bottom: 40px;
}
</style>
<div class="about" style="margin: 0px;padding-top: 40px; box-shadow: none;">

<div class="container">
<h2 class="about__header" data-title="Вопрос - Ответ">Вопрос - Ответ

</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 30px;letter-spacing: 2px;">Ответы на часто задаваемые вопросы</h6>
<div class="about__description" style="box-shadow: 0px 5px 55px rgba(0, 0, 0, 0.09);background: #fff;border-radius: 10px;padding: 30px;">
<div class="faq_list">
<div class="faq_block" style="margin-bottom: 20px;">
<div style="font-weight:600; color: #2f2f2f;">1) Что такое <?=$sitename?>?</div>
<div class="answer">Это уникальная, безопасная, инвестиционная онлайн платформа. Команда <?=$sitename?>, состоит из опытных трейдеров, которые в свою очередь могут обеспечить стабильный доход нашим инвесторам!
</div>
</div>
<div class="faq_block" style="margin-bottom: 20px;">
<div style="font-weight:600; color: #2f2f2f;">2) Кто может инвестировать в <?=$sitename?>?</div>
<div class="answer">Инвестировать в <?=$sitename?> может любой желающий достигший 18 летнего возраста, в остальном никаких ограничений нет.</div>
</div>
<div class="faq_block" style="margin-bottom: 20px;">
<div style="font-weight:600; color: #2f2f2f;">3) Какие инвестиционные планы вы предлагаете?</div>
<div class="answer">Мы предлагаем инвестировать средства и получать <b style="font-weight:600; color: #2f2f2f;"><?=$deppercentage?>% прибыли</b> ежедневно, ваш доход зависит от суммы инвестиций. Срок депозитов составляет <?=$timex_dep?> часа. Более детально ознакомиться с тарифом можно на главной странице!</div>
</div>
<div class="faq_block" style="margin-bottom: 20px;">
<div style="font-weight:600; color: #2f2f2f;">4) Валюта сайта и с какой платежной системой работаете?</div>
<div class="answer">На данный момент наша платформа работает с платежной системой PAYEER WALLET. Валюта платформы - <b style="font-weight:600; color: #2f2f2f;"><?=$m_curr?></b>. Список платежных систем может корректироваться администрацией проекта!</div>
</div>
<div class="faq_block" style="margin-bottom: 20px;">
<div style="font-weight:600; color: #2f2f2f;">5) Как сделать мой первый депозит?</div>
<div class="answer">Для создания депозита вам необходимо пройти несложную процедуру регистрации в системе, после чего ввести сумму депозита в форму и нажать кнопку оплатить, после оплаты ваш депозит автоматически будет в работе!</div>
</div>
<div class="faq_block" style="margin-bottom: 20px;">
<div style="font-weight:600; color: #2f2f2f;">6) Какая минимальная и максимальная сумма депозита?</div>
<div class="answer">Минимальная сумма депозита - <?=$mindep?> рублей, максимальная в свою очередь не может превышать <?=$maxdep?> рублей за один вклад. В системе разрешено иметь один или более депозитов!</div>
</div>
<div class="faq_block" style="margin-bottom: 20px;">
<div style="font-weight:600; color: #2f2f2f;">7) Что нужно сделать, чтобы получить выплату?</div>
<div class="answer">Выплаты на проекте автоматические и не требуют входа в аккаунт. Денежные средства поступают на кошелек, который вы использовали при регистрации на проекте. </div>
</div>

<div class="faq_block" style="margin-bottom: 20px;">
<div style="font-weight:600; color: #2f2f2f;">9) Есть ли у вас партнерская программа?</div>
<div class="answer">Да, у нас присутствует партнерская программа. Доход по партнерской программе составляет <b style="font-weight:600; color: #2f2f2f;"><?=$refpercent?>%</b>, выплаты поступают моментально на ваш кошелек указанный при регистрации!</div>
</div>
<div class="faq_block" style="margin-bottom: 20px;">
<div style="font-weight:600; color: #2f2f2f;">10) Как я могу с Вами связаться</div>
<div class="answer">Если у Вас возникли дополнительные вопросы - перейдите в раздел "Контакты" и свяжитесь с нами по указанным реквизитам, либо используйте онлайн консультант для более быстрого ответа!</div>
</div>
</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/newdep';
</script>
<?}?>