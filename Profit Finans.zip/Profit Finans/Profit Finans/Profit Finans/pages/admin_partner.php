<?if($id == (1)){?>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2>Топы рефоводов</h2>
</div>
<div class="body table-responsive">
<table class="table table-striped table-borderless m-b-5">
<thead>
<tr>
<th style="width:10%;">Номер</th>
<th class="width:20%">Кошелек</th>
<th class="width:30%">Почта</th>
<th style="width:20%;">Пригласил</th>
<th style="width:20%;">Привел на</th>
</tr>
</thead>
<tbody class="no-border-x">
<? 
$checkdeps=$db->getOne("SELECT id FROM ?n WHERE i_have_refs_as_curator>0 LIMIT 1","ss_users");
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM ?n WHERE i_have_refs_as_curator>0 ORDER BY i_have_refs_as_curator DESC LIMIT 200","ss_users");
$i=1;
while($deposits=$db->fetch($depositsrow)){?>
<?$wallet=substr($deposits['wallet'], 0); ?>
 <tr>
 <td><?=$deposits['id']?></td>
 <td><?=$wallet?></td>
 <td><?=$deposits['email']?></td>
 <td><?=$deposits['i_have_refs_as_curator']?> чел.</td>
 <?
$checkdeps=$db->getOne("SELECT SUM(summa) as motherfucker FROM ?n WHERE curatorid=?i","deposits",$deposits['id']);
if(empty($checkdeps)){$checkdeps=0;}
?>
 <td><?=$checkdeps?> <b><?=$m_curr?></b></td>
 </tr>
<?}}?>
</tbody>
</table>
</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}?>