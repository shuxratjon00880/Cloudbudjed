<?if($id > (1)){?>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2>Ваши депозиты</h2>
</div>
<div class="body table-responsive">
<table class="table table-striped table-borderless m-b-5">
<p style="font-weight: normal;">
Здесь отображаются все ваши депозиты, выплаты по которым будут происходить автоматически сразу на ваш payeer кошелек <b><?=$wallet?></b> указанный при регистрации.
</p>
<thead>
<tr>
<th style="width:25%;">Дата</th>
<th class="width:25%">Сумма</th>
<th style="width:25%;">Статус</th>
<th style="width:25%;">На вывод</th>
</tr>
</thead>
<tbody class="no-border-x">
<? 
$checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE userid=?i AND curatorid!=?i LIMIT 1",$id,0);
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM `deposits` WHERE userid=?i AND curatorid!=?i ORDER BY id DESC LIMIT 50",$id,0);
while($deposits=$db->fetch($depositsrow)){?> 
<?$wallet=$db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']);?>
<?$psumma=$deposits['summa']+($deposits['summa']*($deppercentage/100));?>
<tr>
<td><?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
<td class="number"><?=$deposits['summa']?> <b><?=$m_curr?></b></td>
<?
$seconds = time()-$deposits['unixtime'];
$seconds=(60*($depperiod))-$seconds;
if($seconds<1){
if($deposits['status']==1){
$deptime="Выплачено";}else{
$deptime="Выплачивается";
}
}else{

$hours = floor($seconds/3600);
$seconds = $seconds-($hours*3600);
$minutes = floor($seconds/60);
$seconds = $seconds-($minutes*60);
$seconds = floor($seconds);



$h=$hours;
if($h<10){$h='0'.$h;}
$m=$minutes;
if($m<10){$m='0'.$m;}
$s=$seconds;
if($s<10){$s='0'.$s;}
$deptime=$h.":".$m.":".$s;
}
?>
<td class="countdown"><?=$deptime?></td>
<td class="actions"><?=$psumma?> <b><?=$m_curr?></b></td>
</tr>
<?}}?>
</tbody>
</table>
</div>
</div>
</div>
</div>

<?}else{?>
<?if($id == (1)){?>
<script type="text/javascript">
window.location.href = '/?page=admin_deposits';
</script>
<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}}?>