<?if($id == (1)){?>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header"><h2>Очистка базы данных</h2></div>
<div class="body table-responsive">
<center>
<p style=""><b>Внимание!!! Данное действие приведет к частичной очистке БД.<br>
После очистки, зарегистрированные участники останутся на своих местах!</b></p><br>
<?if($_POST['do']=='cleanbd'){
$db->query("TRUNCATE `batches`");
$db->query("TRUNCATE `deposits`");
$db->query("TRUNCATE `log`");
$db->query("TRUNCATE `userstat`");
$db->query("UPDATE more SET plus='0.00'");
$db->query("UPDATE more SET minus='0.00'");
header("Location: /?page=admin_clean");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="hidden" name="do" value="cleanbd">
<button type="submit" name="submit">Очистить базу данных</button>
</form>
</center>
</div>
</div>
</div>
</div>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="body table-responsive">
<center>
<p><b>Внимание!!! Данное действие приведет к полной очистке БД.<br>
После очистки, зарегистрируйте кошелек админа первым на проекте!<br>
ВАЖНО!!! Так же будут удалены все ваши фейки для имитаций пополнений и выплат.</b></p><br>
<?if($_POST['do']=='cleanbdfull'){
$db->query("TRUNCATE `batches`");
$db->query("TRUNCATE `ss_users`");
$db->query("TRUNCATE `deposits`");
$db->query("TRUNCATE `log`");
$db->query("TRUNCATE `userstat`");
$db->query("UPDATE more SET plus='0.00'");
$db->query("UPDATE more SET minus='0.00'");
header("Location: /exit");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="hidden" name="do" value="cleanbdfull">
<button type="submit" name="submit">Очистить базу данных</button>
</form>
</center>

</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}?>