<?if($id == (1)){?>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="body table-responsive">
<center>
<p><b>Для удаления участника, введите его номер кошелька PAYEER</b></p>
<?if (isset($_POST['del_user'])){
$db->query("DELETE FROM ss_users WHERE wallet='".$_POST['del_user']."' ");
header("Location: /?page=admin_users");
if ($db) {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="text" name="del_user" placeholder="Введите номер кошелька">
<button type="submit" name="submit">Удалить</button>
</form>
</center>
</div>
</div>
</div>
</div>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="body table-responsive">
<center>
<p><b>Для смены куратора, введите ID участника и ID нужного куратора</b></p>

<?if (isset($_POST['user_id']) && isset($_POST['new_curator'])){
$db->query("UPDATE ss_users SET curator='".$_POST['new_curator']."' WHERE id='".$_POST['user_id']."' ");
header("Location: /?page=admin_users");
if ($db) {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="text" name="user_id" placeholder="ID участника">
<input type="text" name="new_curator" placeholder="ID куратора">
<button type="submit" name="submit">Сменить</button>
</form>
</center>
</div>
</div>
</div>
</div>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="body table-responsive">
<center>
<p><b>Для изменения пароля участнику, введите ID участника и новый пароль</b></p>
<?if (isset($_POST['puser_id']) && isset($_POST['pnew_pass'])){
$_POST_puser_id = isset($_POST['puser_id']) ? intval($_POST['puser_id']) : 0;
$_POST_pnew_pass = isset($_POST['pnew_pass']) ? hash('sha256', $_POST['pnew_pass']) : '';
if ($_POST_puser_id > 0)
{
  if (strlen($_POST_pnew_pass) > 0 && strlen(trim($_POST['pnew_pass'])) > 0)
  {
    //$db->query("UPDATE deposits SET summa='".$_POST['new_vklad']."' WHERE id='".$_POST['dep_id']."' ");
    $checkus_isset=$db->getOne("SELECT id FROM `ss_users` WHERE id='".$_POST_puser_id."' LIMIT 1");
    if($checkus_isset>0)
	{
	  $db->query("UPDATE ss_users SET wallet_password='".$_POST_pnew_pass."' WHERE id='".$_POST_puser_id."' ");  
      if ($db) {
        echo "Пароль успешно изменён.";
		header("Location: /?page=admin_users");
      } else {
        echo "Произошла ошибка при попытке сменить пароль.";
      }
    } else { echo "Пользователя с указанным ID не существует."; }
  } else { echo "Отсутствует новый пароль"; }
} else { echo "Введите корректный ID участника"; }
}
?>
<form action="" method="POST">
<input type="text" name="puser_id" placeholder="ID участника">
<input type="text" name="pnew_pass" placeholder="Новый пароль">
<button type="submit" name="submit">Изменить пароль</button>
</form>
</center>
</div>
</div>
</div>
</div>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="body table-responsive">
<center>
<p><b>Введите нужное количесто фейковых участников</b></p>
<?if (isset($_POST['feikuser'])){
$db->query("UPDATE more SET feikuser='".$_POST['feikuser']."' ");
header("Location: /?page=admin_users");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлено - <font color="red"><b><?=$feyk?></b></font> чел.</p>
<input type="text" name="feikuser" placeholder="Количество фейков">
<button type="submit" name="submit">Добавить</button>
</form>
</center>
</div>
</div>
</div>
</div>


<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2>Здесь отображаются регистрации новых участников</h2>
</div>
<div class="body table-responsive">
<table class="table table-striped table-borderless m-b-5">
<thead>
<tr>
<th style="width:5%;">Номер</th>
<th class="width:10%">Кошелек</th>
<th class="width:15%">Почта</th>
<th style="width:5%;">Куратор</th>
<th style="width:10%;">ip адрес</th>
<th style="width:35%;">Ресурс</th>
<th style="width:20%;">Регистрация</th>
</tr>
</thead>
<tbody class="no-border-x">
<? 
$depositsrow=$db->query("SELECT * FROM `ss_users` ORDER BY `ss_users`.`id` DESC limit 1000");
 $i=1; 
while($deposits=$db->fetch($depositsrow)){?>
<tr>
<td><?=$deposits['id']?></td>
<td><?=$deposits['wallet']?></td>
<td><?=$deposits['email']?></td>
<td><?=$deposits['curator']?></td>
<td><?=$deposits['ip']?></td>
<td><?=$deposits['came']?></td>
<td><b><?=@date('d.m.Y H:i',$deposits['reg_unix'])?></b></td>
</tr>
<?}?>
</tbody>
</table>
</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}?>