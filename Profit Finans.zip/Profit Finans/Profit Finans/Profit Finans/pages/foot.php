<?if(!empty($_error)){?><center><div class="stat" style="position: fixed;display: inline-block;font-size: 16px;color: rgb(250, 250, 250);z-index: 10;right: 17px;top: 100px;box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 3px;border: 1px solid rgba(255, 255, 255, 0);width: 330px;background: rgba(4,35,50,0.45);height: 140px;border-radius: 4px;line-height: 3.42857143;"><div style="color: rgb(255, 255, 255); font-size: 16px; height: 30px; padding: 0px;">Сообщение</div><font><?=$_error?></font></div></center><?}?>
<?if(!empty($_success)){?><center><div class="stat" style="position: fixed;display: inline-block;font-size: 16px;color: rgb(250, 250, 250);z-index: 10;right: 17px;top: 100px;box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 3px;border: 1px solid rgba(255, 255, 255, 0);width: 330px;background: rgba(4,35,50,0.45);height: 140px;border-radius: 4px;line-height: 3.42857143;"><div style="color: rgb(255, 255, 255); font-size: 16px; height: 30px; padding: 0px;">Сообщение</div><font><?=$_success?></font></div></center><?}?>

<?if($id == (1)){?>

<div class="row clearfix">
<div class="col-md-12">
<div class="card">
<div class="body">
<p class="copy m-b-0">Этот скрипт принадлежит php-scripts <a href="https://php-scripts.ru" target="_blank"><font color="red">Посетить сайт</font></a></p>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- Jquery Core Js --> 
<script src="/style/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 
<script src="/style/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 

<script src="/style/bundles/jvectormap.bundle.js"></script> <!-- JVectorMap Plugin Js -->
<script src="/style/bundles/sparkline.bundle.js"></script> <!-- Sparkline Plugin Js -->
<script src="/style/bundles/morrisscripts.bundle.js"></script><!-- Morris Plugin Js -->
<script src="/style/bundles/flotscripts.bundle.js"></script><!-- Flot Charts Plugin Js -->

<script src="/style/bundles/mainscripts.bundle.js"></script>
<script src="/style/js/pages/index.js"></script>
</body>
</html>

<?}else{?>
<?if($id > (1)){?>

<div class="row clearfix">
<div class="col-md-12">
<div class="card">
<div class="body">
<p class="copy m-b-0" style="text-align: center;">Project created by <a href="https://php-scripts.ru" target="_blank"><u><span>PHP-scripts</span></u></a></p>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- Jquery Core Js --> 
<script src="/style/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 
<script src="/style/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 

<script src="/style/bundles/jvectormap.bundle.js"></script> <!-- JVectorMap Plugin Js -->
<script src="/style/bundles/sparkline.bundle.js"></script> <!-- Sparkline Plugin Js -->
<script src="/style/bundles/morrisscripts.bundle.js"></script><!-- Morris Plugin Js -->
<script src="/style/bundles/flotscripts.bundle.js"></script><!-- Flot Charts Plugin Js -->

<script src="/style/bundles/mainscripts.bundle.js"></script>
<script src="/style/js/pages/index.js"></script>
</body>
</html>

<?}else{?>

<footer>
<div class="container">
<div class="bottom-footer clearfix" style="margin-top: 10px;padding: 30px 10px 30px;">
<p style="text-align: left;width: 35%;float: left;padding-left: 50px;line-height: 24px;">
<img src="/tema/img/logo1.png" style="position: absolute;width: 50px;margin-left: -55px;margin-top: -3px;">
Все права защищены! <br>© <?php echo date('Y'); ?> <?=$host?></p>
<div id="top-menu-f">
<ul>
<li><a href="/">Главная</a></li>
<li><a href="/about"> О проекте</a></li>
<li><a href="/rules"> Правила</a></li>
<li><a href="/faq"> FAQ</a></li>
<li style="padding-right: 0px;"><a href="/contacts"> Контакты</a></li>
</ul>
</div>
</div>
</div>
</footer>
</div>
<script type="text/javascript" src="/tema/theme.js"></script>
<script src="/tema/waves.js"></script>
<div id="toTop"><i class="fa fa-chevron-up"></i></div>
<script src="/tema/widget.js"></script>

</body>
</html>

<?}}?>