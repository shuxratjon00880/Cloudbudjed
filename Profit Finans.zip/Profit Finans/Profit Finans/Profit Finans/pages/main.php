<?if(empty($id)){?>

<div class="lider">
<header class="theme-menu-two transparent-menu">
<div class="main-header">
<div class="container">
<div class="logo float-left" style="margin-left: 20px;">
<a href="/"><img src="/tema/img/logo.png" style="position: absolute;width: 400px;margin-left: -10px;margin-top: 0px;"></a>
</div>

<div class="menu-wrapper float-right">
<nav id="mega-menu-holder" class="menuzord menuzord-responsive">
<ul class="menuzord-menu menuzord-indented scrollable">
<li><a href="/">Главная</a></li>
<li><a href="/about"> О проекте</a></li>
<li><a href="/rules"> Правила</a></li>
<li><a href="/faq"> FAQ</a></li>
<li><a href="/contacts"> Контакты</a></li>
<li><a href="<?=$vkgrup?>" target="_blank"><i class="fa fa-vk"></i></a></li>
<li><a href="<?=$telega?>" target="_blank"><i class="fa fa-send"></i></a></li>
</ul>
</nav> 
</div> 
</div> 
</div>
</header>

<div id="banner">
<div class="rev_slider_wrapper">
<div id="business-main-banner">
<div class="tp-caption text-center"><h1><?=$sitename?></h1></div>
<div class="tp-caption text-center">
<p>Теперь у каждого желающего есть возможность стать частью нашей команды <br> и начать зарабатывать вместе с нами! </p></div>

<div class="tp-caption text-center">
<style>
label {
position: relative;
display: inline-block;
width: 50px;
height: 50px;
cursor: pointer;
border-radius: 50px;
box-shadow: 0 12px 20px -10px rgba(21, 148, 193, 0.09), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgb(18, 157, 183);
padding: 6px;
margin-top: 1px;
background: #fff;
}

</style>

<div style="width: 779px;padding-left: 391px;height: 51px;padding-top: 16px;">
<button onclick="location.href = '#sign-in'" class="in" style="float: left;">Войти</button>
<button onclick="location.href = '#sign-up'" class="up" style="float: right;">Регистрация</button>
</div>
</div>

<div class="tp-caption">
<div class="block-head">
<h1 style="font-size: 19px;margin-top: 45px;margin-bottom: 40px;letter-spacing: 1px;font-weight: 900;">Всего 3 простых шага</h1>
<div class="d-flex mb-4">
<img src="/tema/img/1.svg" alt="">
<span>Пройдите несложную регистрацию</span>
</div>
<div class="d-flex mb-4">
<img src="/tema/img/2.svg" alt="">
<span>Введите сумму и оплатите депозит</span>
</div>      
<div class="d-flex mb-4">
<img src="/tema/img/3.svg" alt="">
<span>Получайте ежедневно прибыль</span>
</div> 
</div>
<img src="/tema/img/object.png" alt="Image" style="width: 1196px;height: 472px;margin-top: 0px;position: relative;">

<div class="col-md-23">			   
<div class="row">
<div style="padding: 0px;margin-top: 2px;">
<table class="table table-striped">
<thead style="color: #0e0e0f;font-family: &#39;Montserrat&#39;, sans-serif;font-weight: 500;font-size: 15px;"> 
<tr style="border-bottom: 2px solid #ededed;">
<td>Дата</td>
<td>Кошелек</td>
<td>Депозит</td>
<td>Осталось</td>
<td>Сумма</td>
</tr> 
</thead>
<tbody style="color: #000000b5;">  
<? 
$checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE status='0' LIMIT 1");
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM `deposits` WHERE status='0' ORDER BY id DESC LIMIT 8");
while($deposits=$db->fetch($depositsrow)){?> 
<?$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0, -3); ?>
<tr>
<td><?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
<td><?=$wallet?><b style="font-size: 18px;color: #e9394d;line-height: 0px;"> •••</b></td>
<td><?=$deposits['summa']?> <?=$m_curr?></td>
<?//-(60*($depperiod)) - длительность депа в секундах
$seconds = time()-$deposits['unixtime']; //Секунд прошло с момента депа

$seconds=(60*($depperiod))-$seconds; //Длительность депа, минус прошло = осталось
//echo "<br>".date('H:i:s',time());
//echo "<br>".date('H:i:s',$deposits['unixtime'])."<br>".$seconds;
if($seconds<1){
    if($deposits['status']==1){
	$deptime="Выплачено";}else{
	$deptime="В обработке";
	}
}else{
	
$hours = floor($seconds/3600);
$seconds = $seconds-($hours*3600);
$minutes = floor($seconds/60);
$seconds = $seconds-($minutes*60);
$seconds = floor($seconds);



$h=$hours;
if($h<10){$h='0'.$h;}
$m=$minutes;
if($m<10){$m='0'.$m;}
$s=$seconds;
if($s<10){$s='0'.$s;}
	$deptime=$h.":".$m.":".$s;
}
?>
<td class="countdown"><?=$deptime;?></td>
<?$psumma=$deposits['summa']+($deposits['summa']*($deppercentage/100));?>
<td style="font-weight: 600;font-family: &#39;Montserrat&#39;, sans-serif;"><?=$psumma?> <?=$m_curr?></td>
</tr>
<?}}?> 


</tbody>
</table>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="about">
<div style="padding: 60px 0px;">
<div class="container">
<div class="row">
<div class="col-md-offset-1 col-xs-6 text-right fsz-16 pt-15 xs-text" style="margin-left: 2%;width: 61%;">
<p class="index-a-text">В течение нескольких лет мы занимались трейдингом на фондовых биржах. Благодаря накопленному опыту нам удалось достичь высоких результатов. Именно так у нас возникла идея создания инвестиционной платформы. </p>
</div>
<div class="col-xs-5" style="padding-left: 70px;padding-top: 6px;width: 35%;">
<img src="/tema/img/logo1.png" alt="" style="position: absolute;width: 60px;margin-left: -65px;margin-top: 1px;">
<h2 class="section-title" style="padding-top: 5px;"> <span class="light-font"></span> <strong style="font-size: 27px;"><?=$sitename?> </strong> </h2>
<h4 class="sub-title">Немного о нас</h4>
</div>
</div>
</div>
</div>
<div class="container">
<h2 class="about__header" data-title="Инвестиционные предложения">Инвестиционное предложение</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 60px;letter-spacing: 2px;">Мы для Вас подобрали лучшее инвестиционное предложение</h6>
<div class="about__description">
<div class="row">

<a style="display: block;">
<div class="col-xs-12 text-center">
<div class="product-box index-s-block" style="box-shadow: 0px 5px 55px rgba(0, 0, 0, 0.26);">
<div class="product-media" style="height: 140px;">
<div style="position: absolute;margin-top: 30px;margin-left: 102px;z-index: 999;font-size: 25px;color: #ffffff;font-weight: 900;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.14);">Profit</div>
<div style="position: absolute;margin-top: 106px;margin-left: 105px;z-index: 999;font-size: 30px;color: #4a4a4b;font-weight: 700;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.09);">1<?=$deppercentage?>%</div>
<img class="shape" alt="" src="/tema/img/shap-small.png">
</div>
<div class="product-caption">
<p><b>Полный срок</b><i><?=$timeprofit?></i></p>
<p><b>Сумма</b><i>от <?=$mindep?> до <?=$maxdep?></i></p>
<p><b>Профит</b><i>+<?=$deppercentage?>%</i></p>
<p><b>Выплаты</b><i>автоматические</i></p>
<p><b>Валюта</b><i><?=$m_curr?></i></p>
<div class="price">
</div>
</div>
</div>
</div>
</a>

</div>
</div>
</div>

<div class="container" style="padding: 0px 0px 80px !important;">
<h2 class="about__header" data-title="Преимущества платформы">Преимущества платформы</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 60px;letter-spacing: 2px;">Детальная информацио о наших преимуществах</h6>
<div class="container" style="text-align: center;">
<div class="row">
<div class="col-xs-4">
<div class="leftp" style="margin-top: 40px;">
<h1 class="lh1">Партнерская программа <?=$refpercent?>%</h1>
<p class="lefp" style="padding-left: 20px;">Приглашайте партнеров, и получайте <?=$refpercent?>% от их пополнений, что позволит вам зарабатывать без вложений</p> 
<img class="ileftp" src="/tema/img/feat_1.png">
</div>
<div class="leftp">
<h1 class="lh1" style="padding-left: 20px;">Безопасность личных данных</h1>
<p class="lefp">Наши технические специалисты следят за безопасностью ваших личных данных, ежедневно обновляя платформу</p> 
<img class="ileftp" src="/tema/img/feat_3.png">
</div>
</div> 
<div class="col-xs-4">
<div class="phone">
<div class="wrapper">
<div class="cfix">
</div>
<div class="scroll">
<ul class="inner" id="calc_result"></ul>
</div>
</div>
</div>
</div>  


<div class="col-xs-4">
<div class="rightp" style="margin-top: 40px;">
<h1 class="rh1">Продуманный маркетинг</h1>
<p class="rigp">Плавный, продуманный маркетинг дает нам перспективы на долгое сотрудничество с нашими инвесторами</p> 
<img class="irightp" src="/tema/img/feat_5.png"></div>
<div class="rightp">
<h1 class="rh1">Техническая поддержка 24/7</h1>
<p class="rigp">Наша техподдержка оказывает эффективную помощь в решении любых интересующих вас вопросов.</p> 
<img class="irightp" src="/tema/img/feat_2.png">
</div>
</div>
</div>
</div>
</div>
</div> <div style="padding: 40px 0px;background-repeat: no-repeat;background-image: url(/tema/img/slide-1.jpg);color: rgba(255, 255, 255, 0.59);background-size: cover;background-position: center center;box-shadow: 0 0 0 241px rgba(0, 0, 0, 0.07) inset;">
<div class="container">
<div class="about__list" style="margin-bottom: 0px;">
<div class="about__item" style="color: #fff;font-family: &#39;Montserrat&#39;, sans-serif;letter-spacing: 0.4px;border-right: 1px dashed #f1f3f6;">
<b style="text-align: center;">Дата старта<br><font style="font-size: 22px;"><?=$data_starta?></font></b>
</div>
<div class="about__item" style="color: #fff;font-family: &#39;Montserrat&#39;, sans-serif;letter-spacing: 0.4px;border-right: 1px dashed #f1f3f6;">
<b style="text-align: center;">Инвестировано<br><font style="font-size: 22px;"><?=$depmoney?> <?=$m_curr?></font></b>
</div>
<div class="about__item" style="color: #fff;font-family: &#39;Montserrat&#39;, sans-serif;letter-spacing: 0.4px;border-right: 1px dashed #f1f3f6;">
<b style="text-align: center;">Всего участников<br> <font style="font-size: 22px;"><?=$uzerov?></font></b>
</div>

<div class="about__item" style="text-align: center;color: #fff;font-family: &#39;Montserrat&#39;, sans-serif;letter-spacing: 0.4px;">
<b class="hide-shortcut__">Выплачено <br> <font style="font-size: 22px;"><?=$wthmoney?> <?=$m_curr?></font></b>
</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/newdep';
</script>
<?}?>