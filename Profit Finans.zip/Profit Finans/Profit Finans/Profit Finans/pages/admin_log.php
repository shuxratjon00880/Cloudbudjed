<?if($id == (1)){?>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2>Ошибки выплат</h2>
</div>
<p style="margin-bottom: -11px;">
<center>
<p><b>Чтобы вернуть депозит в работу, введите ID депозита</b></p>
<?if (isset($_POST['vernut_oshibki'])){
$db->query("UPDATE `deposits` SET `status` = '0' WHERE `deposits`.`id` = '".$_POST['vernut_oshibki']."'");
header("Location: /?page=admin_log");
if ($db) {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="text" name="vernut_oshibki" placeholder="Введите ID депозита">
<button type="submit" name="submit">Вернуть в работу</button>
</form>
</center>
</p>

<div class="body table-responsive">
<table class="table table-striped table-borderless m-b-5">
<thead>
<tr>
<th style="width:20%;">Дата вклада</th>
<th class="width:20%">ID депозита</th>
<th style="width:20%;">Кошелек</th>
<th style="width:20%;">Сумма</th>
<th style="width:20%;">Статус</th>
</tr>
</thead>
<tbody class="no-border-x">
<? 
$depositsrow=$db->query("SELECT * FROM `deposits` WHERE status=?i AND curatorid!=?i ORDER BY id DESC LIMIT 1000",2,0);
while($deposits=$db->fetch($depositsrow)){?>
<?$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0); ?>
<tr>
<td><?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
<td>ID > <?=$deposits['id']?></td>
<td><?=$wallet?></td>
<?
if($deposits['curatorid']==0){
$wdthrw=$deposits['summa'];
}else{
$wdthrw=($deposits['summa']+($deposits['summa']*($deppercentage/100)));	
}
?>
<td><?=$wdthrw?> <b><?=$m_curr?></b></td>
<td>Не выплачено</td>
</tr>
<?}?>
</tbody>
</table>
</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}?>