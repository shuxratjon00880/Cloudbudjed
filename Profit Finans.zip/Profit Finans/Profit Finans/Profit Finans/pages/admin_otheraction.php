<?if($id == (1)){?>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2>Настройки проекта</h2>
</div>
<div class="body table-responsive">
<p style="margin-bottom: -11px;">
<center>
<p><b>Установка даты старта проекта!</b></p>
<?if (isset($_POST['data_start'])){
$db->query("UPDATE more SET start='".$_POST['data_start']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$data_starta?></b></font></p>
<input type="text" name="data_start" placeholder="Дата старта">
<button type="submit" name="submit">Установить</button>
</form>
</center>
</p>
</div>
</div>
</div>
</div>

<!--//-->
<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<p style="margin-bottom: -11px;">
<center>

<p><b>Установка почты администратора!</b></p>

<?if (isset($_POST['mail'])){
$db->query("UPDATE more SET mail='".$_POST['mail']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$adminmail?></b></font></p>
<input type="text" name="mail" placeholder="Почта проекта">
<button type="submit" name="submit">Установить</button>
</form>
</center>
</p>
</div>
</div>
</div>
</div>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<p style="margin-bottom: -11px;">
<center>

<p><b>Установка ссылки на Вконтакте!</b></p>

<?if (isset($_POST['vk'])){
$db->query("UPDATE more SET vk='".$_POST['vk']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$vkgrup?></b></font></p>
<input type="text" name="vk" placeholder="Ссылка на Вконтакте">
<button type="submit" name="submit">Установить</button>
</form>
</center>
</p>
</div>
</div>
</div>
</div>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<p style="margin-bottom: -11px;">
<center>

<p><b>Установка ссылки на Телеграм!</b></p>

<?if (isset($_POST['telega'])){
$db->query("UPDATE more SET telega='".$_POST['telega']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$telega?></b></font></p>
<input type="text" name="telega" placeholder="Ссылка на Телеграм">
<button type="submit" name="submit">Установить</button>
</form>
</center>
</p>
</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}?>