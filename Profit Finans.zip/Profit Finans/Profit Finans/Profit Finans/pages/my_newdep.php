<?if($id > (1)){?>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2>Открытие нового депозита</h2>
</div>
<div class="body table-responsive">

<center>
<p>Введите сумму вклада от <?=$mindep?> до <?=$maxdep?> <?=$m_curr?></p>
<form action="" method="post">	
<input type="hidden" name="do" value="payeer_pay">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<input autocomplete="off" name="m_amount" type="text" placeholder="Введите сумму вклада" style="margin-bottom: 10px;">
<button type="submit" name="submit" id="form">ОПЛАТИТЬ ДЕПОЗИТ</button>
</form>
</center>

</div>
</div>
</div>
</div>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2>История пополнений</h2>
</div>
<div class="body table-responsive">
<table class="table table-striped table-borderless m-b-5">
<thead>
<tr>
<th style="width:25%;">Дата</th>
<th style="width:25%;">Операция</th>
<th style="width:25%;">Сумма</th>
<th style="width:25%;">Статус</th>
</tr>
</thead>
<tbody class="no-border-x">
<? 
$depositsrow=$db->query("SELECT * FROM `log` WHERE userid=?i AND comment='Пополнение баланса' ORDER BY id DESC limit 200",$id);
 $i=1; 
while($deposits=$db->fetch($depositsrow)){?>
<?$wallet=$db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']);?>
<tr>
<td><?=date('d.m.Y H:i',$deposits['timeunix'])?></td>
<td><?=$deposits['summa']?> <b><?=$m_curr?></b></td>
<td><?=$deposits['comment']?></td>
<td>Успешно</td>
</tr>
<?}?>
</tbody>
</table>
</div>
</div>
</div>
</div>

<?}else{?>
<?if($id == (1)){?>
<script type="text/javascript">
window.location.href = '/?page=admin_deposits';
</script>
<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}}?>